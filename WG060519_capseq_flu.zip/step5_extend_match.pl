use strict;
use warnings;
my $min=19;

print "sample name (no _all and no 2040):";
my $sam=<>; chomp $sam;
my @sam=split /\s*\,\s*/,$sam;
my %flu; &get_fluseq (\%flu); #% pos vs. seq, including RC
foreach my $sam (@sam)     {
&get_extension ($sam);
&get_extra ($sam.'2040');  }

sub get_extra                                             {
my ($sa)=@_;
open (hand1,"$sa\_all/$sa\_all\_$min\_extended.txt") or die $!;
my %all; my %id; my %ex;
while (<hand1>)                  {
$_ =~ s/\s+$//;
my @a1=split /\t/;
next if /^>/;
#next if $a1[1] eq '+';
my $ex='No_extra';
if ($a1[7] >1)                {
$ex=substr($a1[6],0,$a1[7]-1);}
$id{$a1[6]}{$ex}=$a1[4];         }
close hand1;

# if one sequence generates >1 extra
foreach my $fu (keys %id)             {
my $count=scalar keys %{$id{$fu}};
foreach my $ex (keys %{$id{$fu}})   {
$ex{$ex}{$fu}=$id{$fu}{$ex}/$count; } }
%id=();


foreach my $ex (keys %ex)            {
my $sum=0;
foreach my $fu (keys %{$ex{$ex}}) {
$sum+=$ex{$ex}{$fu};              }
$all{$ex}=$sum;                      }

open (hand1,">$sa\_all/$sa\_all\_extra\_uni.txt");
foreach my $ex (sort {$all{$b}<=>$all{$a}} keys %all)  {
print hand1 ">$ex\_x$all{$ex}\n";    
foreach my $fu (sort {$ex{$ex}{$b}<=>$ex{$ex}{$a}} keys %{$ex{$ex}}) {
print hand1 "$fu\t$ex{$ex}{$fu}\n";                                  }
                                                       }
close hand1;                                              }

#extension                                                   
sub get_extension                                      {
my ($sam)=@_; my $sa=$sam.'2040';
my %id; &get_id ($sa,\%id);#short vs. long
my %se; &get_rna ($sam, \%se); #intact read sequence

open (hand1,"$sa\_all/$sa\_all\_$min.txt") or die $!;
open (hand2,">$sa\_all/$sa\_all\_$min\_extended.txt");
while (<hand1>)                                   {
$_ =~ s/\s+$//;
if (/^>/) {print hand2 "$_\n";next;} #chr id

my ($ch,$sr,$st,$en,$re,$id,$se,$mt)=split /\t/;

#fix + strand mut position from relative to 20 to relative to 0
if ($sr eq '+' && $mt ne 'N')       {
my @mt=split /:|\,/,$mt; $mt='';
foreach (my $i=0; $i<$#mt; $i+=2){
my $po=20+$mt[$i];
$mt.=$po.':'.$mt[$i+1].',';      }
$mt =~ s/\,$//;                     }

my $chid=$ch; $chid.='RC' if $sr eq '-';
my @id=@{$id{$id.'_x'.$re}}; #sub id
foreach my $idre (@id)                       {
my $rse=$se{$idre}; #full size sequence
my ($oid,$rea)=split /_x/,$idre;
print "wrong sequence\n" if substr($rse,20) ne $se; #check the last 20 nt

my $ast=$st; #relative to waston or crick
if ($sr eq '-')                   {
my $ssi=scalar keys %{$flu{$chid}}; #size of chr
$ast=$ssi+1-($st+$en);            }
my $mp=0; my $ms=-1; my %m;
&extend_match ($chid,$rse,$ast,\$mp,\$ms,\%m);

#mut position is referring to 21 (as 0 for '+') or 40 (as 0 for '-')
#no mutation within extended match
if ($ms <1)                 {
print hand2 "$ch\t$sr\t$st\t$en\t$rea\t$oid\t$rse\t21\t40\t$mt\tN\n";
next;                       }

# extension of match position referring to chr and read + strand
my $qst=21+$mp; my $e=$en-$mp;
my $s=$st; $s+=$mp if $sr eq '+';
print hand2 "$ch\t$sr\t$s\t$e\t$rea\t$oid\t$rse\t$qst\t40\t$mt";

#with mutations within extended match
my $mm='N';
foreach my $p (sort {$a<=>$b} keys %m) {
#mut position is referring to 1 (as 0 for '+') or 40 (as 0 for '-')
my $mpo=20+$p; $mpo =19-$p if $sr eq '-';
my $wm= $m{$p};
if ($sr eq '-')        {     
$wm =~ tr/AGCT/TCGA/;  }
$mm.=','.$mpo.':'.$wm;                 }

$mm =~ s/^N\,//; print hand2 "\t$mm\n";     }    }
close hand1; close hand2;                               }

sub extend_match                            {
my ($ch,$se,$st,$mp,$ms,$m)=@_;  
my $lt=20; $lt=$st-1 if $st <21;

my $sc; my %mt;
for (my $i=1;$i<=$lt;$i++)    {
my $snt=$flu{$ch}{$st-$i};
my $qnt=substr $se,20-$i,1;

if ($snt eq $qnt)  {
$sc+=1;            }
else               {
$mt{-$i}=$snt.$qnt;
$sc+=-3;           }

if ($sc >=$$ms)         {
$$ms=$sc; $$mp=-$i;     }    }

foreach my $i (keys %mt)     {
if ($i>=$$mp)           {
${$m}{$i}=$mt{$i};      }    }
%mt=();                                   }

#get collapsed ID
sub get_rna                    {
my ($sam,$se)=@_; my $id;
open (hand1,"fastaq/$sam/$sam\_$min\_uni.txt") or die $!;
while (<hand1>)   {
$_ =~ s/\s+$//;
if (/^>/)      {
$id=$_;
$id =~ s/^>//;
next;          }
${$se}{$id}=$_;   }
close hand1;                  }         

#get collapsed ID for 5' trimmed sequence
sub get_id                    {
my ($sam,$id)=@_; my $cid;
open (hand1,"fastaq/$sam/$sam\_$min\_id.txt") or die $!;
while (<hand1>)            {
$_ =~ s/\s+$//;
if (/^>/)         {
$cid=$_;
$cid =~ s/^>//;
next;             }
@{${$id}{$cid}}=split /-/; }
close hand1;                  }                            

#get flu sequence
sub get_fluseq                          {
my ($flu)=@_;
open (hand1,"BB_used.fa") or die $!;
my $id; my %se;
while (<hand1>)    {
$_ =~ s/\s+$//;
if (/^>/)       {
$id=$_; $id =~ s/^>//;
next;           }
$_ =~ s/\s+//g;
$se{$id}.=$_;      }
close hand1;

foreach my $ch (keys %se)           {
my $lt=length($se{$ch});
for (my $p=1; $p <=$lt; $p++)    {
my $rp=$lt+1-$p;
my $ns=substr($se{$ch},$p-1,1);
my $nr=$ns; $nr =~ tr/AGCT/TCGA/;
${$flu}{$ch}{$p}=$ns;
${$flu}{$ch.'RC'}{$rp}=$nr;      }  }
%se=();                                }
