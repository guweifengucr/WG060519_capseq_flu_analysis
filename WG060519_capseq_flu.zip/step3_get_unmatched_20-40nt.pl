use strict;
use warnings;
print "Sample name (no _all):";
my $sample=<>; chomp $sample;
my @sam=split /\s*\,\s*/,$sample;
my $min=19;
my @n=(0..9,'a'..'z');
foreach (@sam)     {
&get_unmatched($_);}

sub get_unmatched                                    {
my ($sam)=@_; my %mat;
open (hand1,"$sam\_all/$sam\_all\_$min\_geex_normed.txt") or die $!;
while (<hand1>)      {
$_ =~ s/\s+$//;
my @a1=split /\t/;
$mat{$a1[7]}=1;      }
close hand1;

open (hand1,"fastaq/$sam/$sam\_$min\_uni.txt") or die $!;
my $id; my $re; my %unm; my %id;
while (<hand1>)                      {
$_ =~ s/\s+$//;
if (/^>/)            {
($id,$re)=split /_x/;
$id =~ s/^>//;
next;                }
next if exists $mat{$_};
$unm{substr($_,20)}+=$re;
$id{substr($_,20)}.='-'.$id.'_x'.$re; }
close hand1;

my $i=61000000; $sam.=2040;
mkdir "fastaq/$sam";
open (hand1,">fastaq/$sam/$sam\_$min\_uni.txt");
open (hand2,">fastaq/$sam/$sam\_$min\_id.txt");
foreach (sort {$unm{$b} <=> $unm{$a}} keys %unm) {
$i++; my $hex=convert_to_36 ($i);
print hand1 ">$hex\_x$unm{$_}\n$_\n";
my $lid=$id{$_}; $lid=~ s/^-//;
print hand2 ">$hex\_x$unm{$_}\n$lid\n";          }
close hand1; close hand2;                            }

sub convert_to_36           {
my ($n)=@_;

my $out=$n[$n % 36];
$n=int($n/36);

until ($n <1)         {
$out=$n[$n % 36].$out;
$n=int($n/36);        }
return $out;                }
