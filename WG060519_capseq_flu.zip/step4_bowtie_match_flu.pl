use strict;
use warnings;
use Getopt::Std;
print "sample names (no _all), separated by comma:";
my $sam=<>; chomp $sam;
my $stan='nons';#cose, tot, geex
my $av='-v'; #-v for sequence only and -n for with quality score
my $mis=1; #mismatch
my $maxhit=10; #max hits
my $index='/home/wglabpred/Desktop/bowtie-0.12.7/indexes/BB_used.fa'; #ref index
my $min=19; #minimum size
my $getr=2; #1 for gene analysis and 2 for transcript analysis
my $exsi=5;

#############################################################
#add samples and run here
foreach my $sa (split (/\s*\,+\s*/,$sam)){
&run_match($sa.'2040');                  }
#############################################################


# # # # # # # # # # # # # # all subs# # # # # # # # # # # # # # #
#### run bowtie match
sub run_match                                               {
my ($sam)=@_;
my $rec2=`bowtie $av $mis -p 4 -f -B 1 -a --best --strata -m $maxhit $index fastaq/$sam/$sam\_$min\_uni.txt bowtie0127/$sam\_$min\_all.tmp`;
mkdir "$sam\_all";#mkdir "$sam\_per";

&filter_major ($sam);
                                                            }

####split into all, per, and mut, and filter out non-specific
sub filter_major                                            {
my ($sam)=@_; my %all; my %aa;

my %tmp; my $id='?' x 100; my $minsc=1000000000;
open (hand1,"bowtie0127/$sam\_$min\_all.tmp") or die $!;
open (hand2,">bowtie0127/$sam\_$min\_all.temp");
while (<hand1>)                 {
$_ =~ s/\s+$//;
my @a1=split /\t/;
my $sc=0;
if ($a1[7])                  {
my @mt=split /\,/,$a1[7];
$sc=$#mt+1;                  }

if ($a1[0] eq $id)           {
if ($sc>$minsc)     {
next;               }
elsif ($sc <$minsc) {
$minsc=$sc;
%tmp=();         
$tmp{$_}=$sc;       }
else                {
$tmp{$_}=$sc;       }        }

else                         {
my $hit=scalar keys %tmp;
foreach my $f (keys %tmp) {
my @f=split /\t/,$f;
print hand2 "$f[0]\t$f[1]\t$f[2]\t$f[3]\t$f[4]\t$f[5]\t$hit";
my $mut="\n"; $mut="\t$f[7]\n" if $f[7];
print hand2 $mut;         }
%tmp=(); $id=$a1[0];
$tmp{$_}=$sc; $minsc=$sc;    }  }

my $hit=scalar keys %tmp;
foreach my $f (keys %tmp)    {
my @f=split /\t/,$f;
print hand2 "$f[0]\t$f[1]\t$f[2]\t$f[3]\t$f[4]\t$f[5]\t$hit";
my $mut="\n"; $mut="\t$f[7]\n" if $f[7];
print hand2 $mut;            }
%tmp=(); close hand1; close hand2;
unlink "bowtie0127/$sam\_$min\_all.tmp";

open (hand1,"bowtie0127/$sam\_$min\_all.temp") or die $!;
while (<hand1>)                                          {
$_ =~ s/\s+$//; my @a1=split /\t/;
my $chr=$a1[2];
my ($id,$re)=split (/_x/,$a1[0]);#read and id
my $str=$a1[1];my $sta=$a1[3];
my $end=length($a1[4])-1;
my $rna=$a1[4];
if ($a1[1] eq "-")     {
$rna=reverse $rna;
$rna =~ tr/AGCT/TCGA/; }

#fix mutation pos according to genome
my $mut='N';
if ($a1[7])                     {
my @mut=split (/\,/,$a1[7]);
foreach my $m (@mut)          {
my ($po,$mt)=split (/\:/,$m);
$mt=~ s/>//;
my $mtpo=$po;
if ($a1[1] eq '-') {
$mtpo=$end-$po;    }
$mut.="\,".$mtpo."\:".$mt;    }
$mut=~ s/N\,//;                 }


if ($a1[7])                             {
my @mut=split (/\,/,$a1[7]);
my $mxmt=int((length($a1[4])-10)/5);
$mxmt=0 if $mxmt<0;
my $m=$#mut+1; next if $m > $mxmt;  
$all{$chr}{"$chr\t$str\t$sta\t$end\t$re\t$id\t$rna\t$mut"}=1;
$aa{$rna}=$re;
next;                                   }
$all{$chr}{"$chr\t$str\t$sta\t$end\t$re\t$id\t$rna\t$mut"}=1;
$aa{$rna}=$re;                                            }
close hand1;
unlink "bowtie0127/$sam\_$min\_all.temp";

open (hand1,">$sam\_all/$sam\_all\_$min.txt");
open (hand2,">$sam\_all/sum\_$sam\_all\_$min.txt");
foreach my $id (sort {$a cmp $b} keys %all)  {
print hand1 ">",$id,"\n"; my $se=0; my $an=0; my $sum=0;
foreach my $fea (keys %{$all{$id}})      {
my @f=split /\t/,$fea; $sum+=$f[4];
$se+=$f[4] if $f[1] eq '+';
$an+=$f[4] if $f[1] eq '-';
if ($fea ne 'empty')       {
print hand1 $fea,"\n";     }             }
print hand2 "$id\t$se\t$an\t$sum\n";         }       
close hand1; %all=(); my $tot=0;

foreach my $rna(keys %aa)  {
$tot+=$aa{$rna};           }
print hand2 "\nTotal\t$tot\n";
close hand2; %aa=();                                        }                   
