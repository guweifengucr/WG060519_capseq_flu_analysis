use strict;
use warnings;
my $min=19; my $motifsize=20;#the motif size is an even number
print "sample names:";
my $sam=<>; chomp $sam;
my @sam=split /\s*\,+\s*/,$sam;
my %bbsize; #BBS7 use 1026 instead of 1027
$bbsize{'BBS1'}=2339;$bbsize{'BBS2'}=2340;$bbsize{'BBS3'}=2232;$bbsize{'BBS4'}=1774;
$bbsize{'BBS5'}=1564;$bbsize{'BBS6'}=1461;$bbsize{'BBS7'}=1026;$bbsize{'BBS8'}=889;

foreach (@sam) {
	&grab_full_seq ($_.'2040_all',\%bbsize);
}

sub grab_full_seq {
	my ($sa,$bb)=@_; my $on=0; my %codon; my %fil; my %vseq; my $id; my %motif;
	&codon(\%codon); my %print;

	#%vseq: key BBS and value flu seq #BBS1 missing G at 28
	open (hand1,"BB_used.fa") or die $!;
	while (<hand1>) {
		$_ =~ s/\s+$//;
		if (/^>/) {
			$_ =~ s/\s+$//;
			$id =$_;
			$id =~ s/^>//;
			next;
		}
		$vseq{$id}.=$_;
	}
	close hand1;
	foreach my $str (keys %vseq) {
		my $s=$vseq{$str};
		$s = reverse $s;
		$s =~ tr/ACGT/TGCA/;
		$vseq{$str}=$s;
	}

	#indel related 'artificial cap
	open (my $fh,"3_filter_for_indel_caused_extra_seq.txt") or die $!;
	while (<$fh>) {
		$_ =~ s/\s+$//;
		$fil{$_}=1;
	}
	close $fh;

	#processing
	open ($fh,"$sa/$sa\_$min\_extended.txt") or die $!;
	while (<$fh>) {
		if (/^>/) {
			$on=0;
			$on=1 if /^>BBS/; #only process BBS
			next;
		}
		next if $on ==0;
		$_ =~ s/\s+$//;
		
		my @a1=split /\t/; $a1[1] =~ tr/-\+/\+-/;
		my $sta=$a1[2]+$a1[3]; $sta=length($vseq{$a1[0]})+1-$sta; $a1[2]=$sta;
		my $fe="$a1[0]\t$a1[1]\t$a1[2]\t$a1[3]\t$a1[4]\t$a1[5]\t$a1[6]\t$a1[7]\t$a1[8]\t$a1[9]\t$a1[10]";
		next if $a1[9] ne 'N' || $a1[10] ne 'N'; #no mutation for cap and flu
		next if $a1[7] < 10 || $a1[7] >16; #cap >=9 nt & <15

		my $ex=substr ($a1[6],0,$a1[7]-1);
		next if exists $fil{$ex}; #remove top indel
		next if $a1[1] eq '-'; # only for vRNA
		next if $a1[2] >10; #only keep the first 10
		my $fullseq=$ex.substr ($vseq{$a1[0]},$a1[2]-1);#cap+flu
		my @pr; &translate_aa ($fullseq,\%codon,\@pr);#translate three frame

		for my $frprseq (@pr) {
			my ($fr,$prseq)=split /\t/,$frprseq;#fr vs protein
			my %longpep;#for the same M, use this to only keep the longest peptide
			while ($prseq=~ /M/g) {#search each M
				my $po=pos($prseq)-1;
				my $nseq=substr ($prseq, $po);#grab M and the following including stop codon
				if ($nseq =~ /^(M\w+)/) {#find M....stop
					my $pepseq=$1;
					if (length ($pepseq) >=50) {#peptide size >=50
						$po*=3; $po+=$fr;
						my $flup;#upstream M
						if ($po <$motifsize/2) {
							$flup=substr($fullseq,0,$po);
						}
						else {
							$flup=substr($fullseq,$po-$motifsize/2,$motifsize/2);
						}
						
						my $fldown=substr($fullseq,$po,$motifsize/2); #downstream M
						next if $fldown !~ /^ATGG/ || $flup !~ /[AG]\w\w$/;#RNNATGG for kozak filter
						my $count=0;
						
						foreach my $exist (keys %longpep) {
							if ($exist =~ /$pepseq/) {
									$count++;
							}
						}
						next if $count >0;
						$longpep{$pepseq}=1;
						$motif{"$flup\t$fldown"}++;
						my $vpos;
						while ($vseq{$a1[0]} =~ /$fldown/g) {
							my $sta=pos($vseq{$a1[0]})-$motifsize/2+1;
							$vpos.=$sta.'_';
						}
						$vpos.='mixed';
						$vpos =~ s/_mixed$//;
						$print{$pepseq}{$fe."\t"."$flup\t$vpos\t$fldown"}=1;
					}
				}
			}
		}
	}

	open (my $fh2,">$sa/$sa\_$min\_cap_to_flu_end_first-10_translation_vRNA.txt");
	foreach my $pr (sort {$a cmp $b} keys %print) {
		my $prna='no_match';					
		print $fh2 ">$pr\t$prna\n";
		foreach my $s (sort {$a cmp $b} keys %{$print{$pr}}) {
			$s =~ s/^>//;
			print $fh2 "$s\n";
		}
	}
	print "\n";
	foreach my $s (sort {$motif{$b}<=>$motif{$a}} keys %motif) {
		print $fh2 "$s\t$motif{$s}\n";
	}
	close $fh; close $fh2;
}

#translation
sub translate_aa {
	my ($seq,$codon,$p) =@_;
	for my $frame (0..2) {
		my $se=substr ($seq, $frame);
		my $si=int(length($se)/3);    
		if ($si==0) {
			print "too small to translate\n";
			next;
		}
		my $pr;
		for (my $i=0; $i<$si; $i++) {
			$pr.=${$codon}{substr($se,$i*3,3)};
		}
		push @$p,$frame."\t".$pr;
	}
}

#codon
sub codon {
	my ($ha)=@_;
	open (hand1,"codon.txt") or die $!;
	while (<hand1>)             {
		$_ =~ s/\s+$//;
		my ($seq,$co)=split /\t/;
		${$ha}{$seq}=$co;
	}
close hand1;
}
