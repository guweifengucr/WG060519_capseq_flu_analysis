use strict;
use warnings;
print "Sample name (no _all):";
my $sample=<>; chomp $sample;
my @sam=split /\s*\,\s*/,$sample;
my $min=19;
foreach (@sam)     {
&get_unmatched($_);}

sub get_unmatched                                    {
my ($sam)=@_; my %mat;
open (hand1,"$sam\_all/$sam\_all\_$min\_geex_normed.txt") or die $!;
while (<hand1>)      {
$_ =~ s/\s+$//;
my @a1=split /\t/;
$mat{$a1[7]}=1;      }
close hand1;

open (hand1,"fastaq/$sam/$sam\_$min\_uni.txt") or die $!;
$sam.='40'; mkdir "fastaq/$sam";
open (hand2,">fastaq/$sam/$sam\_$min\_uni.txt") or die $!;
my $id;
while (<hand1>)           {
$_ =~ s/\s+$//;
if (/^>/)            {
$id=$_;
next;                }
next if exists $mat{$_};

print hand2 "$id\n$_\n";  }
close hand1; close hand2;                            }                                       
