use strict;
use warnings;
use Getopt::Std;
print "sample names separated by coma:";
my $sample=<>; chomp $sample;
my $stan='nons';#cose, tot, geex, nons
my $av='-n'; #-v for sequence only and -n for with quality score
my $mis=2; #mismatch
my $maxhit=200; #max hits
my $index='/home/wglabpred/Desktop/bowtie-0.12.7/indexes/HSGRCH3771all'; #ref index
my %chid; my %chty; &ref_id (\%chid,\%chty); #ref id
#my $rec1=`export PATH=\$PATH:/home/wayf/Desktop/bowtie0127`; #bowtie path
my $min=19; #minimum size
my $getr=2; #1 for gene analysis and 2 for transcript analysis
my $filum='no'; # remove piRNA or miRNA from protein coding

#############################################################
#add samples and run here
my @sam=split /\s*\,\s*/,$sample;

foreach my $sam (@sam)            {
&run_match($sam);
&run_post ("$sam\_all");
#&run_post ("$sam\_per");         
                                  }

#############################################################
%chid=(); %chty=();


# # # # # # # # # # # # # # all subs# # # # # # # # # # # # # # #
#### run bowtie match
sub run_match                                               {
my ($sam)=@_;
my $rec2=`bowtie $av $mis -p 4 -l 26 -f -B 1 -e 120 -a --best --strata --chunkmbs 512 -m $maxhit $index fastaq/$sam/$sam\_$min\_uni.txt bowtie0127/$sam\_$min\_all.temp`;

mkdir "$sam\_all";#mkdir "$sam\_per";
&filter_major ($sam);
&fix_coor ("$sam\_all");
&add_rna ($sam);
&fix_cdna("$sam\_all"); #&filter_perf ($sam);
                                                            }

#### run post match
sub run_post                                                {
my ($sam)=@_;
#log file, to avoid redundancy, reopen it 
open (hand111,">$sam/sum\_$sam.txt"); close hand111;
open (hand111,">>$sam/sum\_$sam.txt"); print hand111 
"sample name: $sam
sequence only (-v) or with quality score (-n): $av
max mismatch: $mis\nmax hits: $maxhit
reference index: $index\nminimum size: $min
gene or transcript: $getr, 1 for gene and 2 for transcript
#####################################################\n";

#sum before matching
&sum_fasta($sam);

# merge cdna and genome
my %hitno; &merge($sam,\%hitno);

#repeat-normalization
my @major =('geex','cdna');
foreach my $gr (@major) {&norm ($sam,$gr,\%hitno);} %hitno=();

# count for each major category like cDNA,genome, etc
print hand111 "\nReads matched to each category of genomic loci:
Type\tsense\tanti\tall\n";
foreach  my $gr (@major)                                     {
&countall($gr,"$sam/$sam\_$min\_$gr\_normed.txt",6,1,4,5,6); }

# sum each category of cDNA - individually and wholly
print hand111 "#####################################################\n";
print hand111 "\nReads matched to each category of cDNA:
Type\tsense\tanti\tall\n";
my @cdna=('protein','NMD','NSD','proscript','miRNA','retintron','lincRNA','antisense','propseudo', 'unpropseudo','trunpropseudo','polymorpseudo','unipseudo','pseudo','trpropseudo','struc','Ab');
foreach my $gr (@cdna) {&cdna_sum($sam,$gr);}

#count ex-ex
&ex_no($sam);

#sum the size and start of each major category
&sum_loci($sam,"$sam\_$min\_geex_normed.txt",6,1,4,5,'genome_exex');
&sum_loci($sam,"$sam\_$min\_cdna_protein_normed.txt",6,1,4,5,'protein');
close hand111; 

#make gff
&gff($sam);                                                 }


####split into all, per, and mut, and filter out non-specific
sub filter_major                                            {
my ($sam)=@_;
my %all; my %tmp; my $id='?' x 100; my $minsc=1000000000;
open (hand1,"bowtie0127/$sam\_$min\_all.temp") or die $!;
open (hand2,">$sam\_all/$sam\_all\_$min\_genome.temp");
open (hand3,">$sam\_all/$sam\_all\_$min\_cdna.temp");
while (<hand1>)                 {
$_ =~ s/\s+$//;
my @a1=split /\t/;

#count the mutation number and filter
my $sc=0;
if ($a1[7])                  {
my @mt=split /\,/,$a1[7];
$sc=$#mt+1;                  }
next if $sc > int((length($a1[4])-25)/5);  

#find the smallest $sc for a read match
if ($a1[0] eq $id)           {
if ($sc>$minsc)     {
next;               }
elsif ($sc <$minsc) {
$minsc=$sc;
%tmp=();         
$tmp{$_}=$sc;       }
else                {
$tmp{$_}=$sc;       }        }

#print the best read matches and reset 
else                         {
foreach my $f (keys %tmp) {
my @f=split /\t/,$f;
if ($f[2] =~ /genome/)  {
print hand2 "$f\n";     }
elsif ($f[2] =~ /cdna/) {
print hand3 "$f\n";     } }
%tmp=(); $id=$a1[0];
$tmp{$_}=$sc; $minsc=$sc;    }  }

foreach my $f (keys %tmp) {
my @f=split /\t/,$f;
if ($f[2] =~ /genome/)  {
print hand2 "$f\n";     }
elsif ($f[2] =~ /cdna/) {
print hand3 "$f\n";     } }
%tmp=(); close hand1; close hand2; close hand3;
unlink "bowtie0127/$sam\_$min\_all.temp";                   }


####split all matches
sub fix_coor                                                {
my ($sam)=@_;

#reformat according to genome coordinates
foreach my $gr (qw(genome cdna))                       {
my %all; # sort according to reference id
foreach my $id (keys %{$chty{$gr}})  {           
$all{$chid{$id}}{'empty'}=1;         }

open (hand1,"$sam/$sam\_$min\_$gr.temp") or die $!;
while (<hand1>)                                   {
$_ =~ s/\s+$//; my @a1=split /\t/;
my ($ch,$ty)=split (/\|/,$a1[2]);
my $chr=$chid{$ch}; my $nam=$chr;
my @chr=split (/\t/,$chr); #id information
$chr=$chr[5] if $chr[5];

my ($id,$re)=split (/_x/,$a1[0]);#read and id
my $str=$a1[1];
my $sta=$a1[3];
my $end=length($a1[4])-1;
my $rna=$a1[4];
if ($a1[1] eq "-")     {
$rna=reverse $rna;
$rna =~ tr/AGCT/TCGA/; }

#fix mutation pos according to genome
my $mut='N';
if ($a1[7])                      {
my @mut=split (/\,/,$a1[7]);
foreach my $m (@mut)          {
my ($po,$mt)=split (/\:/,$m);
$mt=~ s/>//;
my $mtpo=$po;
if ($a1[1] eq '-') {
$mtpo=$end-$po;    }
$mut.="\,".$mtpo."\:".$mt;    }
$mut=~ s/N\,//;                  }

$all{$nam}{"$chr\t$str\t$sta\t$end"." ".$id." ".$mut}=1;
                                                 }                              
close hand1; unlink "$sam/$sam\_$min\_$gr.temp";

my $grna=$gr;
if ($grna eq 'cdna')   {
$grna.='_step1';       }
open (hand2,">$sam/$sam\_$min\_$grna.tmp");
foreach my $id (sort {$a cmp $b} keys %all) {
print hand2 ">$id\n";
foreach my $fea (keys %{$all{$id}}) {
if ($fea ne 'empty')     {
print hand2 $fea,"\n";   }          }       }       
close hand2; %all=();                                 }    }


#add read sequnence
sub add_rna                                                {
my ($sam)=@_; my $id; my $re; my %rna;
my $sa=$sam;
open (hand1,"fastaq/$sam/$sam\_$min\_uni.txt") or die $!;
while (<hand1>)          {
$_ =~ s/\s+$//;
if (/^>/)             {
$_=~ s/^>//;
($id,$re)=split /_x/;
next;                 }
$rna{$id}="$re\t$_";     }
close hand1;

my @type =('genome','cdna_step1');
foreach my $type (@type)                              {
open (hand1,"$sam\_all/$sam\_all\_$min\_$type.tmp") or die $!;
open (hand2,">$sam\_all/$sam\_all\_$min\_$type.txt");
while (<hand1>)            {
if (/^>/)              {
print hand2 $_;
next;                  }

if ($_ =~ / (\S+) /)   {
$id=$1;
my ($re,$se)=split /\t/,$rna{$id};
$_ =~ s/ \S+ /\t$re\t$id\t$se\t/;
print hand2 $_;        }
else                   {
print "No read id\n";  }   }
close hand1; close hand2;                            
unlink "$sam\_all/$sam\_all\_$min\_$type.tmp";        }    
%rna=();                                                  }

####fix cDNA coordinates and split ex-ex junctions
sub fix_cdna                                              {
my ($sam)=@_; my %expos;
#genome coordinate intervals of cdna annotations
open (hand1,'HSGRCH3771_cdna_pos_final.txt') or die $!;
while (<hand1>)                      {
$_ =~ s/\s+$//;
my ($id,$po)=split /\|/;
@{$expos{'>'.$id}}=split (/ /,$po);  }
close hand1;                                        

#fix pos and exex
my @expos;
open (hand1,"$sam/$sam\_$min\_cdna_step1.txt") or die $!;
open (hand2,">$sam/$sam\_$min\_cdna.txt");
while (<hand1>)                                     {
$_ =~ s/\s+$//; my @a1=split /\t/; 
if (/^>/)                                       {
@expos=();
foreach my $in (@{$expos{$_}}) {
my ($l,$r)=split (/\t/,$in);
for my $p ($l..$r)     {
push (@expos,$p);      }       }
@expos=sort {$a<=>$b} @expos;
print hand2 $_,"\n"; next;                      }

my $st=$expos[$a1[2]-1];
my $en=$expos[$a1[2]+$a1[3]-1]-$st;

my $mut='N';
if ($a1[7] =~ /\:/)               {
my @mut=split (/\,/,$a1[7]);
foreach my $m (@mut)           {
my ($po,$mt)=split (/\:/,$m);
my $mtpo=$expos[$a1[2]+$po-1]-$st;
$mut.="\,".$mtpo."\:".$mt;     }
$mut=~ s/N\,//;                   }

#split ex-ex
my @ex; my $end3=$a1[2]+$a1[3];
for my $p ($a1[2]..$end3) {
push (@ex,$expos[$p-1]);  }
@ex=sort {$a<=>$b} @ex;

if ($ex[-1]-$ex[0] >$#ex)                    {
$mut.="\t".$ex[0];
for (my $i=0; $i<$#ex;$i++)               {
if ($ex[$i+1]-$ex[$i] >1)              {
my $r=$ex[$i]-$st; my $l=$ex[$i+1]-$st;
$mut.='-'.$r.'_'.$l;                   }  }
my $last=$ex[-1]-$st;
$mut.='-'.$last;                             }
print hand2 $a1[0],"\t",$a1[1],"\t",$st,"\t",$en,"\t",$a1[4],"\t",$a1[5],"\t",$a1[6],"\t",$mut,"\n";
                                                  }
close hand1; close hand2; %expos=(); @expos=();
unlink "$sam/$sam\_$min\_cdna_step1.txt";               }

#short gene or genome id vs. long id; 
sub ref_id                                              {
my ($chid,$chty)=@_;
open (hand1,"HSGRCH3771_all_id.txt") or die $!;
while (<hand1>)                                     {
$_ =~ s/\s+$//;
my ($id,$name)=split /\|/; ${$chid}{$id}=$name;     }
close hand1;                                            

open (hand1,"HSGRCH3771_all_seq.fa") or die $!;
while (<hand1>)                                     {
next if !/^>/; $_ =~ s/^>//;$_ =~ s/\s+$//;
my ($id,$minor)=split /\|/; ${$chty}{$minor}{$id}=1;}
close hand1;                                            }

sub filter_perf                                         {
my ($sam)=@_;
foreach my $ty('genome','cdna')            {
open (hand1,"$sam\_all/$sam\_all\_$min\_$ty.txt") or die $!;
open (hand2,">$sam\_per/$sam\_per\_$min\_$ty.txt");
while (<hand1>)              {
$_ =~ s/\s+$//;
my @a1=split /\t/;
if (/^>/)                  {
print hand2 $_,"\n"; next; }
if ($a1[7] eq 'N')         {
print hand2 $_,"\n";       } }
close hand1; close hand2;                 }             }

#### sum fasta
sub sum_fasta                                                             {
my ($sam)=@_; my $id; my $read; my %size; my %sta; my $tot=0;
$sam =~ s/\_(all|mut|per).*//;
open (hand1,"fastaq/$sam/$sam\_$min\_uni.txt") or die $!;
while (<hand1>)              {
$_ =~ s/\s+$//;
if (/>/)                {
($id,$read)=split /_x/;
next;                   }
$size{length($_)}+=$read;
$sta{substr($_,0,1)}+=$read; }
close hand1;

print hand111 "\nSize before matching:\n";
foreach my $size (sort {$a<=>$b} keys %size)  {
$tot+=$size{$size};
print hand111 $size,"\t",$size{$size},"\n";   }
%size=();

print hand111 "\n1st nt before matching:\n";
foreach my $nt (sort {$a cmp $b} keys %sta)   {
print hand111 $nt,"\t",$sta{$nt},"\n";        }
print hand111 "\nTotal reads before matching $tot\n";
print hand111 "#####################################################\n";
%sta=();                                                                  }

#### merge and sum
sub merge                                                                 {
my ($sam,$hino)=@_; my %hit;
open (hand1,"$sam/$sam\_$min\_genome.txt") or die $!;
open (hand2,">$sam/$sam\_$min\_geex.txt");
while (<hand1>)      {
my @a1=split (/\t/);
if (!/>/)          {
print hand2 $_;
${$hino}{$a1[5]}++;} }
close hand1; close hand2;
unlink "$sam/$sam\_$min\_genome.txt";

open (hand1,"$sam/$sam\_$min\_cdna.txt") or die $!;
while (<hand1>)               {
my @a1=split /\t/;
if ($_ !~ />/ && $#a1 == 8){
$hit{$_}=1;                }  }
close hand1;

open (hand1,">>$sam/$sam\_$min\_geex.txt");
foreach (keys %hit)  {
my @a1=split /\t/;
${$hino}{$a1[5]}++;
print hand1 $_;      }
close hand1; %hit=();                                                     }


#### normalization
sub norm                                                                  {
my ($sam,$type,$hit) =@_;
open (hand1,"$sam/$sam\_$min\_$type.txt") or die $!;
open (hand2,">$sam/$sam\_$min\_$type\_normed.txt");
while (<hand1>)                             {
if (/>/)                  {              
print hand2 $_; next;     }
my @a1=split /\t/;
my $ht =${$hit}{$a1[5]};                     
print hand2 $a1[0],"\t",$a1[1],"\t",$a1[2],"\t",$a1[3],"\t",$a1[4],"\t",$ht,"\t",$a1[5],"\t",$a1[6],"\t",$a1[7];
if ($a1[8])               {
print hand2 "\t",$a1[8];  }                 }
close hand1; close hand2; unlink "$sam/$sam\_$min\_$type.txt";            }

#### count file input
sub countall                                                              {  
my ($type,$file,$sstr,$str,$re,$hit,$id)=@_;my $all=0;
my $sen=0; my $ant=0; my %se=(); my %an=(); my $idstr='+';
open (hand1, $file) or die "no $file\n";
while (<hand1>)                                       {
$_ =~ s/\s+$//;my @a1=split /\t/;
if (/>/)                     {
$idstr=$a1[$sstr];next;      }    

my $uni=$a1[0]."\t".$a1[1]."\t".$a1[2]."\t".$a1[3]."\t".$a1[6];
if (defined $a1[9])                             {
$uni=$a1[0]."\t".$a1[1]."\t".$a1[9]."\t".$a1[6];}
my $norm; &reformat_norm ($a1[$re],$a1[$hit],\$norm);    

if ($a1[$str] eq $idstr)     {
$se{$uni}=$norm;             }
else                         { 
$an{$uni}=$norm;             }                        }
close hand1;

foreach my $f (keys %se) {
if (exists $an{$f}){
$se{$f}/=2;
$an{$f}/=2;        }     }

foreach my $f (keys %se) {
$all+=$se{$f};
$sen+=$se{$f};           }
%se=();
foreach my $f (keys %an) {
$all+=$an{$f};
$ant+=$an{$f};           }
%an=();

$all=int($all+0.5);
$sen=int($sen+0.5);
$ant=int($ant+0.5);
print hand111 "$type\t$sen\t$ant\t$all\n";                              }

#### sum each class of cdna
sub cdna_sum                                                            {
my ($sam,$type)=@_;
my %all=();my $id; my $on=0; my %type=(); my %a=(); my $str;

if ($type eq 'struc')        {
$type{'MTtRNA'}=1;
$type{'MTrRNA'}=1;
$type{'snRNA'}=1;
$type{'rRNA'}=1;
$type{'tRNA'}=1;
$type{'snoRNA'}=1;           }
if ($type eq 'Ab')           {
$type{'IGDgene'}=1;
$type{'TRJgene'}=1;
$type{'TRDgene'}=1;
$type{'TRVgene'}=1;
$type{'IGVgene'}=1;
$type{'TRCgene'}=1;          }
else                         {
$type{$type}=1;              }

# filter out miRNA and piRNA from coding
my %fil=();
if ($type eq 'coding' && $filum eq 'yes')                  {
&filter_id ("$sam/$sam\_$min\_cdna_normed.txt",6,\%fil);   }

open (hand1,"$sam/$sam\_$min\_cdna\_normed.txt") or die $!;
open (hand2,">$sam/$sam\_$min\_cdna\_$type\_normed.txt");
while (<hand1>)                                                {
$_=~ s/\s+$//;
my @a1=split /\t/;
# turn on switch, get str and id, make %all
if (/>/)                       {
$str=$a1[6];
$on=0;
if (exists $type{$a1[4]})   {
print hand2 $_,"\n"; 
$id=$a1[1]."\t".$a1[$getr];
$all{$id}{'empty'}=0; $on=1;}
next;                          }

# collapse matches for transcripts or genes
if ($on==1)                                                 {
# remove miRNA and piRNA from coding
if ($type eq 'coding' && exists $fil{$a1[6]}){
next;                                        }
print hand2 $_,"\n";

my $norm; &reformat_norm ($a1[4],$a1[5],\$norm);

my $n=$str."|$a1[1]\t$norm\t$a1[0]\t$a1[2]\t$a1[3]\t$a1[6]";
if ($a1[9])                                       {
$n=$str."|$a1[1]\t$norm\t$a1[0]\t$a1[9]\t$a1[6]"; }
$all{$id}{$n}=0;                                            }  }
close hand1;close hand2; %fil=();

# %a all matches for all genes in this category
open (hand1,">$sam/sum\_$sam\_$min\_cdna\_$type.txt");
foreach my $id (sort {$a cmp $b} keys %all)            {
my @fea=();my $all=0; my $sense=0; my $anti=0;
foreach my $f (keys %{$all{$id}}) {
if ($f ne 'empty') {
$a{$f}=0;
push (@fea,$f);    }              }
if ($#fea >-1)                                 {
&count_single(\@fea,0,1,\$all,\$sense,\$anti); }
print hand1 $id,"\t",$sense,"\t",$anti,"\t",$all,"\n";
delete $all{$id};                                     }
close hand1; %all=(); 

if ($type eq 'struc')                                 {
open (hand1,"$sam/$sam\_$min\_geex\_normed.txt") or die $!;
while (<hand1>)                                    {
$_ =~ s/\s+$//; next if !/^rRNA/;
my @a1=split /\t/;
my $norm; &reformat_norm ($a1[4],$a1[5],\$norm);
my $n='+|'."$a1[1]\t$norm\t$a1[0]\t$a1[2]\t$a1[3]\t$a1[6]";
if ($a1[9])                                      {
$n='+|'."$a1[1]\t$norm\t$a1[0]\t$a1[9]\t$a1[6]"; }
$a{$n}=1;                                          }
close hand1;                                          }

my $all=0; my $sense=0; my $anti=0;
my @f;
foreach my $f (keys %a) {
push (@f,$f);
delete $a{$f};          }
%a=();

if ($#f >-1)                                 {
&count_single(\@f,0,1,\$all,\$sense,\$anti); }
print hand111 $type,"\t",$sense,"\t",$anti,"\t",$all,"\n";              }


#### filter
sub filter_id                                          {
my ($file,$id,$fil)=@_; my $on=0;
open (hand1,$file) or die $!;
while (<hand1>)                                 {
$_ =~ s/\s+$//;my @a1=split /\t/;
if (/^>/)                                     {
$on=0;
if ($a1[4] =~ /miRNA/ || $a1[4] eq 'piRNA') {
$on=1;                                      }
next;                                         }
if ($on ==1)         {
${$fil}{$a1[$id]}=1; }                          }
close hand1; my $count=scalar keys %{$fil};
print "miRNA and piRNA id filtered $count\n";          }

#### count @array input
sub count_single                                       {
my ($ar,$str,$re,$all,$sen,$ant)=@_; my %se; my %an;
$$all=0;$$sen=0;$$ant=0;
until ($#$ar==-1)                    {
my ($st,$f)=split (/\|/,$$ar[0]);
shift @$ar;
my @a1=split (/\t/,$f);

if ($a1[$str] eq $st)   {
$se{$f}=$a1[$re];       }
else                    {
$an{$f}=$a1[$re];       }            }

foreach my $f (keys %se) {
if (exists $an{$f}) {
$se{$f}/=2;
$an{$f}/=2;         }    }
                        
foreach my $f (keys %se) {
$$all+=$se{$f};
$$sen+=$se{$f};          }
%se=();

foreach my $f (keys %an) {
$$all+=$an{$f};
$$ant+=$an{$f};          }
%an=();
                 
$$all=sprintf ("%.2f",$$all);$$all=~ s/\.?0+$//;
$$sen=sprintf ("%.2f",$$sen);$$sen=~ s/\.?0+$//;
$$ant=sprintf ("%.2f",$$ant);$$ant=~ s/\.?0+$//;       }

####format_gff                                                    
sub gff                                                                           {
my ($sam)=@_;
my $ra=1; &norm_tot ($sam,$stan,\$ra); my $j=0;
my %fea; my $id;              

open (hand1,"$sam/$sam\_$min\_geex\_normed.txt") or die $!;
while (<hand1>)                                        {
$_ =~ s/\s+$//; my @a1=split /\t/;
my $norm=$a1[4]/$a1[5]; $norm=int($norm*1000+0.5)/1000;
my $end=$a1[2]+$a1[3]; my $se=$a1[2].'-'.$end;

if ($a1[9])               {
my @ex=split /_|-/,$a1[9];
$ex[0]=0; $se='';
foreach my $p (@ex) {
my $pp=$p+$a1[2];
$se.=$pp.'-';       }
$se =~ s/-$//;            }
$fea{$a1[0]."\t".$a1[1]."\t".$se}+=$norm;              }
close hand1;

open (hand1, ">$sam/$sam\_$min\_geex\_$stan.gff");
$sam=substr $sam,0,length($sam)-2;
foreach my $f (sort {$a cmp $b} keys %fea)                                   {
my ($chr,$str,$ex)=split /\t/,$f;
my @ex=split /-/,$ex;
my $re=$ra*$fea{$f};
next if $re < 1; $re=int($re*10+0.5)/10;

$j++; my $id='R'.$sam.$j;     

if ($ex =~ /-\d+-/)                {
print hand1 "$chr\t$sam\tfr\t$ex[0]\t$ex[-1]\t$re\t$str\t\.\tID $id\n";
                                
for (my $p=0; $p <$#ex; $p+=2)  {
print hand1 "$chr\t$sam\tpr\t$ex[$p]\t$ex[$p+1]\t$re\t$str\t\.\tID $id\n";
                                }  }
else                               {
print hand1 "$chr\t$sam\tex\t$ex[0]\t$ex[-1]\t$re\t$str\t\.\tID $id\n";
                                   }                                        }
close hand1; %fea=();                                                           }


#### exon reads
sub ex_no                                                             {
my ($sam)=@_;my %se; my %an; my $str;
open (hand1,"$sam/$sam\_$min\_cdna\_normed.txt") or die $!;
while (<hand1>)           {
$_ =~ s/\s+$//;
my @a1=split /\t/;
if (/>/)     {
$str=$a1[6];
next;        }

if ($a1[9])            {
my $name=$a1[6]."\t".$a1[0]."\t".$a1[1]."\t".$a1[9];
my $norm; &reformat_norm ($a1[4],$a1[5],\$norm);
if ($a1[1] eq $str)  {
$se{$name}=$norm;    }
else                 {
$an{$name}=$norm;    } }  }
close hand1;

foreach my $f (keys %se)  {
if (exists $an{$f}) {
$se{$f}/=2;
$an{$f}/=2;         }     }

my $all=0;my $sen=0; my $ant=0;
foreach my $f (keys %se)  {
$all+=$se{$f};
$sen+=$se{$f};            }
%se=();

foreach my $f (keys %an)  {
$all+=$an{$f};
$ant+=$an{$f};            }
%an=();

$all=int($all+0.5);
$sen=int($sen+0.5);
$ant=int($ant+0.5);

print hand111 
"#####################################################
\nex-ex:\nsense\tanti\ttotal\n$sen\t$ant\t$all
#####################################################\n";                }
 
#### sum loci
sub sum_loci                                                             {
my ($sam,$file,$ids,$fst,$re,$hit,$type)=@_;
my %se;my %an;my %l;my %ls;my %la;my %s;my %ss;my %sa;my $str='+';

open (hand1,"$sam/$file") or die $!;
while (<hand1>)                                   {
$_ =~ s/\s+$//; my @a1=split /\t/;
if (/>/) {$str=$a1[$ids];next;}

my $rna=$a1[6]."\t".length($a1[7])."\t".substr($a1[7],0,1);
my $name=$rna."\t".$a1[0]."\t".$a1[1]."\t".$a1[2]."\t".$a1[3];
if ($a1[9])                                     {
$name=$rna."\t".$a1[0]."\t".$a1[1]."\t".$a1[9]; }

my $norm;
&reformat_norm ($a1[$re],$a1[$hit],\$norm);

if ($str eq $a1[$fst])  {
$se{$name}=$norm;       }
else                    {
$an{$name}=$norm;       }                         }
close hand1;

foreach my $f (keys %se){
if (exists $an{$f})  {
$se{$f}/=2;
$an{$f}/=2;          }  }

foreach my $f (keys %se){

my @a1=split (/\t/, $f);
$l{$a1[1]}+=$se{$f};
$s{$a1[2]}+=$se{$f};
$ls{$a1[1]}+=$se{$f};
$ss{$a1[2]}+=$se{$f};   }
%se=();

foreach my $f (keys %an){
my @a1=split (/\t/, $f);
$l{$a1[1]}+=$an{$f};
$s{$a1[2]}+=$an{$f};
$la{$a1[1]}+=$an{$f};
$sa{$a1[2]}+=$an{$f};   }
%an=();
  
foreach my $l (keys %l) {
$ls{$l}+=0;$la{$l}+=0;  }

print hand111 "\n$type size matched:\ntype\tsense\tanti\tall\n";
foreach my $l (sort {$a<=>$b} keys %l)  {
my $al=int($l{$l}+0.5);
my $se=int($ls{$l}+0.5);
my $an=int($la{$l}+0.5);
print hand111 $l,"\t$se\t$an\t$al\n";   }

foreach my $s (keys %s){
$ss{$s}+=0;$sa{$s}+=0; }

print hand111 "\n$type 1st nt matched:\ntype\tsense\tanti\tall\n";
foreach my $s (sort {$a cmp $b} keys %s){
my $al=int($s{$s}+0.5);
my $se=int($ss{$s}+0.5);
my $an=int($sa{$s}+0.5);
print hand111 $s,"\t$se\t$an\t$al\n";   }
print hand111 "#####################################################\n";
%l=();%ls=();%la=();%s=();%ss=();%sa=();                                 }

sub reformat_norm                       {
my ($re,$hit,$norm)=@_;
$$norm=$re/$hit;
$$norm =sprintf ("%.2f",$$norm);
$$norm =~ s/\.?0+$//;                   }

####normalization                                                                         
sub norm_tot                                {
my ($sam,$stan,$ratio)=@_;
open (hand1,"$sam/sum\_$sam.txt") or die $!;
my $geex=0; my $struc=0; my $cose=0;
while (<hand1>)                        {
$_ =~ s/\s+$//;
if (/^geex\t\S+\t\S+\t(\S+)/)       {
$geex=$1;                           }
if (/^struc\t\S+\t\S+\t(\S+)/)      {
$struc=$1;                          }
if (/^protein\t(\S+)\t(\S+)\t(\S+)/){
$cose=$1;                           }
last if /^Ab/;                         }
close hand1;

my $nons=$geex-$struc;
print "total $geex
struc $struc
non-struc $nons
sense coding $cose\n";
       
if ($stan eq "cose")           {
$$ratio=5000000/$cose;         }
elsif ($stan eq "nons")        {
$$ratio=10000000/$nons;        }
elsif ($stan eq "tot")         {
$$ratio=10000000/$geex;        }
print "Normalization ratio $$ratio\n\n";      }
