use strict;
use warnings;
#print "Sample name:";
my $sam='112213B59h24480517BBh24';chomp $sam;
print "template sequence:";
my $temp=<>; chomp $temp;
$temp =~ tr/agct/AGCT/;

open (hand1,"fastaq/$sam/$sam\_19_uni.txt") or die $!;
my %re; my $id;
while (<hand1>)               {
$_ =~ s/\s+$//;
if (/^>/)    {$id=$_;next;}
$_ = reverse $_;
$_ =~ tr/ACGT/TGCA/;
$re{$_}=$id;                  }
close hand1;

open (hand0,">fastaq/$sam/$sam\_19_mutations.txt");
my $yes=1;
while ($yes >=-2)                                                        {
$temp =~ tr/agct/AGCT/;
open (hand1,">fastaq/$sam/$sam\_3extended.txt");

my $lt=length($temp) % 70;
my $ln=int(length($temp) / 70);
for (my $i=0; $i <$ln; $i++)             {
print substr($temp,$i*70,70),"\n";
print hand1 substr($temp,$i*70,70),"\n"; }

if ($lt >0)                              {
print hand1 substr($temp,-$lt,$lt),"\n";
print substr($temp,-$lt,$lt),"\n";       }
close hand1;


my $lk;
if ($yes >0)         {
$lk=20;              }
else                 {
print "seed size (default 20):";
$lk=<>; chomp $lk;
if ($lk eq '')   {
$lk=20;          }   }

my $lknt=substr $temp,-$lk,$lk;
open (hand1,">fastaq/$sam/$sam\_19_hits.txt");
foreach (keys %re)                   {
my $id=$re{$_};
my $p=index($_,$lknt,0);
my $mat=0;
if ($p>-1)                         {
my $se=substr $_,0,$p+$lk;
if ($temp =~ /$se$/)             {
$mat++;
$_ =substr $_, $p;
my $lc =$lknt; $lc =~ tr/AGCT/agct/;
$_ =~ s/$lknt/$lc/;
print hand1 "$_\t$id\tse\n";     } } }
close hand1;

my %po; my %poan;
open (hand1,"fastaq/$sam/$sam\_19_hits.txt") or die $!;
while (<hand1>)                                {
$_ =~ s/\s+$//;
my ($seq,$re,$ty)=split /\t/;
$re =~ s/^>\w+_x//;
foreach (my $i=$lk; $i<length($seq);$i++)   {
$po{$i-$lk+1}{substr($seq,$i,1)}+=$re;
$poan{$i-$lk+1}{substr($seq,$i,1)}+=$re if $ty eq 'an';
                                            }  }
close hand1;

my $se; my $exno=0; my $on=1;
foreach my $p (sort {$a<=>$b} keys %po)                             {
my $sum=0; print $p; my $count=0; my $core=0; 
my $suman=0; my $corean=0;
foreach my $n (sort {$po{$p}{$b}<=>$po{$p}{$a}} keys %{$po{$p}}) {
my $nr=$po{$p}{$n}; my $nran=0;
$nran=$poan{$p}{$n} if exists $poan{$p}{$n};
$sum+=$po{$p}{$n};
$suman+=$poan{$p}{$n} if exists $poan{$p}{$n};

print "\t$n\t$nr/$nran";                                       
$count++; 
if ($count==1)                                 {
$se.=$n;
$core=$po{$p}{$n};
$corean=$poan{$p}{$n} if exists $poan{$p}{$n}; }                 }
print "\t$sum/$suman\n";

$on=0 if $core/$sum <0.9 || $sum <10;
if ($on==1)                              {
$exno++ if $core/$sum >=0.9 && $sum >=10;}                           }

if ($exno >0)                {
$yes=$exno;                  }
else                         {
print "No. of nt extended:";
if ($se)                                                          {
my $t=0;
foreach my $n (sort {$po{1}{$b}<=>$po{1}{$a}} keys %{$po{1}})   {
$t+=$po{1}{$n};                                                 }
if ($t>=10)                                                     {
print hand0 length ($temp)+1;
foreach my $n (sort {$po{1}{$b}<=>$po{1}{$a}} keys %{$po{1}}) {
print hand0 "\t$n\t$po{1}{$n}";
my $an=0; $an=$poan{1}{$n} if exists $poan{1}{$n};
print hand0 "/$an";                                           } }
print hand0 "\n";                                                 }
$yes=<>; chomp $yes;         }

if ($yes > 0)                {
my $exse=substr $se, 0, $yes;
$temp.=$exse;
$temp =~ tr/agct/AGCT/;      }   
elsif ($yes == -1)           {
print "type in sequence extended:";
my $exse=<>; chomp $exse;
$temp.=$exse;                }
elsif ($yes == 0)            {
print "No extension. Please use a smaller seed No.\n";
$temp =~ tr/agct/AGCT/;      }
elsif ($yes == -2)                         {
print "No. of nt trimmed from 3' end:";
my $ntno=<>; chomp $ntno;
$temp=substr $temp,0, length ($temp)-$ntno;}
                                                                          }
close hand0;
