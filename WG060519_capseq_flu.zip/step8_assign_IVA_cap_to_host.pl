use strict;
use warnings;

#assign extra seq of >=10 nt to TSS predicted based on known annotations
#hash the 5' extra sequence of size >=10
#extra matching 5' end of non-virus capseq
#hash sense TSS
#hash anti TSS
#assign: print extra seq and reads; if identified by capseq, print 
#capseq loci; if capseq loci are associated with TSS, print sense or anti
print "Sample name (no 2040 and _all) delimited by comma:";
my $sam=<>; chomp $sam; my @sam=split /\s*\,+\s*/,$sam;
my $min=10; #min size of the extra sequence
my $ufs=100; my $dfs=100; my $ufa=300; my $dfa=0;
foreach my $s (@sam)   {
&assign_extra ($s);    }

sub assign_extra                                                         {
my ($sam)=@_;
#hash the 5' extra sequence of size >=10
	my %ex; my $sa=$sam."2040"; my %fil;
	open (my $fh,"3_filter_for_indel_caused_extra_seq.txt") or die $!;
	while (<$fh>) {
		$_ =~ s/\s+$//;
		$fil{$_}=1;
	}
	close $fh;

open (hand1,"$sa\_all/$sa\_all_extra_uni.txt") or die $!;
while (<hand1>)                                 {
$_ =~ s/\s+$//; next if !/^>/;
my ($se,$re)=split /_x/;
$se =~ s/^>//;
next if exists $fil{$se};
next if length($se)<$min || $se eq 'No_extra';
$ex{$se}=$re;                                   }
close hand1;

#extra matching 5' end of non-virus capseq
my %oe;
open (hand1,"$sam\_all/$sam\_all_19_geex_normed.txt") or die $!;
while (<hand1>)                            {
$_ =~ s/\s+$//; my @a1=split /\t/;
#next if $a1[8] ne 'N';
for my $i (10..20)                      {
if (exists $ex{substr($a1[7],0,$i)}) {
$oe{substr($a1[7],0,$i)}{$_}=1;      }  }  }
close hand1;

#hash sense TSS
my %se; my $id; my %an;
open (hand1,"$sam\_all/$sam\_all_cdna_sense_TSS\_$ufs\_$dfs.txt") or die $!;
while (<hand1>)      {
$_ =~ s/\s+$//;
if (/^>/)       {
$id = $_; next; }
my @a1=split /\t/;
next if $a1[0] eq 'pos';
$se{"$a1[0]\t$a1[1]\t$a1[2]"}{$id}=$a1[3];
                     }
close hand1;

#hash anti TSS
open (hand1,"$sam\_all/$sam\_all_cdna_anti_TSS\_$ufa\_$dfa.txt") or die $!;
while (<hand1>)      {
$_ =~ s/\s+$//;
if (/^>/)       {
$id = $_; next; }
my @a1=split /\t/;
next if $a1[0] eq 'pos';
$an{"$a1[0]\t$a1[1]\t$a1[2]"}{$id}=$a1[3];
                     }
close hand1;

#assign
open (hand1,">$sa\_all/$sa\_all_extra_uni_mapped\_$ufs\_$dfs\_$ufa\_$dfa.txt");
foreach my $se (sort {$ex{$b}<=>$ex{$a}} keys %ex)  {
print hand1 ">$se\_x$ex{$se}\n";
next if !exists $oe{$se};
foreach my $f (keys %{$oe{$se}})        {
my @f=split /\t/,$f;
print hand1 $f,"\n";
my $st=$f[2];
$st+=$f[3] if $f[1] eq '-';
my $lo="$f[0]\t$f[1]\t$st";
if (exists $se{$lo})                 {
foreach my $id (keys %{$se{$lo}}) {
$id =~ s/^>//;
print hand1 "sense\t$id\n";       }  }

if (exists $an{$lo})                 {
foreach my $id (keys %{$an{$lo}}) {
$id =~ s/^>//;
print hand1 "anti\t$id\n";        }  }  }          }
close hand1;                                                           }
